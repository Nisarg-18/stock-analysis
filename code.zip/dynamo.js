const AWS = require("aws-sdk");
require("dotenv").config();
AWS.config.update({
  // region: process.env.AWS_DEFAULT_REGION_1,
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

const dynamoClient_1 = new AWS.DynamoDB.DocumentClient({
  region: process.env.AWS_DEFAULT_REGION_1,
});
const dynamoClient_2 = new AWS.DynamoDB.DocumentClient({
  region: process.env.AWS_DEFAULT_REGION_2,
});

const USER_TABLE_NAME = "users";
const STOCKS_TABLE_NAME = "stocksData";

const getUserFromReplica = async (email) => {
  const params = {
    TableName: USER_TABLE_NAME,
    Key: {
      email: email,
    },
  };
  return await dynamoClient_2.get(params).promise();
};

const getUser = async (email) => {
  const params = {
    TableName: USER_TABLE_NAME,
    Key: {
      email: email,
    },
  };
  return await dynamoClient_1.get(params).promise();
};

const getStockDataById = async (id) => {
  // const params = {
  //   TableName: STOCKS_TABLE_NAME,
  //   Select: "COUNT",
  // };
  // return await dynamoClient_1.scan(params).promise();
  const params = {
    TableName: STOCKS_TABLE_NAME,
    Key: {
      id: parseInt(id),
    },
  };
  return await dynamoClient_1.get(params).promise();
};

const getHighAndLow = async (company) => {
  const params = {
    TableName: STOCKS_TABLE_NAME,
    FilterExpression: "#symbol = :symbol",
    ExpressionAttributeNames: {
      "#symbol": "symbol",
    },
    ExpressionAttributeValues: {
      ":symbol": company,
    },
  };
  return await dynamoClient_1.scan(params).promise();
};

const addUser = async (user) => {
  const params = {
    TableName: USER_TABLE_NAME,
    Item: user,
  };
  return await dynamoClient_1.put(params).promise();
};

const addUserFromReplica = async (user) => {
  const params = {
    TableName: USER_TABLE_NAME,
    Item: user,
  };
  return await dynamoClient_2.put(params).promise();
};

// const deleteUser = async (id) => {
//   const params = {
//     TableName: USER_TABLE_NAME,
//     Key: {
//       id,
//     },
//   };
//   return await dynamoClient_1.delete(params).promise();
// };

module.exports = {
  dynamoClient_1,
  getUser,
  getStockDataById,
  addUser,
  getUserFromReplica,
  addUserFromReplica,
  getHighAndLow,
};
